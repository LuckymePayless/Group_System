from tkinter import *
from tkinter import messagebox
from pygame import mixer
import datetime

mixer.init() #Initializing the mixer

# All of this Funtion is for turning back to normal button and destroying the window/toplevel
def NormalGasolinePrice():
    Gasoline_Price.config(state="normal")
    Price_Container.destroy()

def NormalAboutUs():
    About_Us_button.config(state="normal")
    About_Us.destroy()

def NormalUserManual():
    Manual.config(state="normal")
    User_Manual.destroy()

def NormalDiesel():
    Diesel.config(state="normal")
    Gasoline_Type_Diesel.destroy()

def NormalPremium():
    Premium.config(state="normal")
    Gasoline_Type_Premium.destroy()

def NormalUnleaded():
    Unleaded.config(state="normal")
    Gasoline_Type_Unleaded.destroy()

def NormalKerosene():
    Kerosene.config(state="normal")
    Gasoline_Type_Kerosene.destroy()

# Receipt Funtion
def Receipt():

    Date = datetime.datetime.now()
    CurrentDate =Date.strftime("%B %d, %Y")
    CurrentTime = Date.strftime("%I:%M %p")

    Receipt_Window = Toplevel(window,bg="#FAEAC8")
    Receipt_Window.geometry("300x600")
    Receipt_Window.resizable(False,False)

    Label(Receipt_Window,text="LuckymePayless",bg="#FAEAC8",font=("Times new roman",15,"bold")).pack(side=TOP,pady=10)
    Label(Receipt_Window,text="Heinics@gmail.com\n"
        "093-343-324-243"
        ,bg="#FAEAC8").pack()
    Label(Receipt_Window,text="---------------------------------------------------------------------",bg="#FAEAC8").pack()
    Label(Receipt_Window,text=f'  {CurrentDate}\t\t\t{CurrentTime}',bg="#FAEAC8").pack(anchor="w")
    Label(Receipt_Window,text="---------------------------------------------------------------------",bg="#FAEAC8").pack()
    # Type of Fuel
    Label(Receipt_Window,text=f'  Tax\t\t\t\t     0',bg="#FAEAC8").pack(anchor="w")
    Label(Receipt_Window,text="---------------------------------------------------------------------",bg="#FAEAC8").pack()
    Label(Receipt_Window,text=f'  Total\t\t\t\t     {Total_Amount}',bg="#FAEAC8").pack(anchor="w")
    Label(Receipt_Window,text=f'  Change\t\t\t\t     {Change}',bg="#FAEAC8").pack(anchor="w")
    Label(Receipt_Window,text="---------------------------------------------------------------------",bg="#FAEAC8").pack()
    Label(Receipt_Window,text="Thank You",font=("Arial",15,"bold"),bg="#FAEAC8").pack(side="bottom",pady=20)

#Abour Us Funtion 
def AboutUs():
    # Author Funtion
    def Autor():
      Text_Container_One.config(
            text="LuckymePayless team would like to acknowlage the\n"
            "following contributors:\n"
            "Programmers name\n"
            "------------------------------------",
            font=("Times new roman",10,"bold"),
            fg="green",
            justify="left"
            )
      Text_Container_Two.config(font=("Areal",10),
            text="● Ilyer Jhon Sibayan Tapiz\n"
            "● Giland Lomboy\n"
            "● Alexarose Ignacio\n"
            "● Gener Miranda\n"
            "● Princess Mae Lorenzo",
            justify="left"
            )
    # About System Funtion
    def AboutSystem():
        Text_Container_One.config( 
                text="With teamwork, dedication, and innovation, we built\n"
                "Gasoline System to meet the needs of businesses and\n"
                "individuals who rely on accurate monitoring and management.\n"
                "We are committed to continuous improvement, ensuring that\n"
                "the system grows with the evolving demands of its users\n"
                "\nAt Gasoline System, we value\n:"
                "Efficiency – making transactions faster and more reliable.\n"
                "Accuracy – ensuring data and records are correct.\n"
                "Innovation – developing features that enhance user experience.\n"
                "Thank you for choosing Gasoline System. Together we fuel\n"
                "progress\n",
                font=("Times new roman",8,"bold"),
                fg="green",
                justify="left",
                )
        Text_Container_Two.config(text="")
    
    global About_Us
    About_Us =  Toplevel(window)
    About_Us.title("About Us")
    About_Us.geometry("700x400")
    About_Us.resizable(False,False)

    About_Us_button.config(state="disabled")
    About_Us.protocol("WM_DELETE_WINDOW",NormalAboutUs)

    System_Logo = Label(About_Us,image=Photo)
    System_Logo.place(x=40,y=75)

    Heading = Label(About_Us,text="Gasoline System",font=("Times new roman",20,"bold","underline"))
    Heading.place(x=400 , y=15)


    About_Us_Text_Conatiner = Frame(About_Us,height=200,width=360,bd=2,relief="solid")
    About_Us_Text_Conatiner.place(x=300,y=100)
    About_Us_Text_Conatiner.pack_propagate(FALSE)
    
    About_Us_Nav_Conatiner = Frame(About_Us,bg="lightgray",height=0)
    About_Us_Nav_Conatiner.pack(side="bottom",fill="x")

    Autors = Button(About_Us_Nav_Conatiner,
                    bd=0,highlightthickness=0,
                    text="Authors",
                    fg="blue",
                    font=("Areal",10,"underline"),
                    bg="lightgray",
                    command=Autor,
                    height=3,
                    activebackground="lightgray",
                    activeforeground="blue"
                    )
    Autors.place(y=0,x=50)
    Autors.pack_propagate(False) 
                                                                                              

    About_System = Button(About_Us_Nav_Conatiner,
                    bd=0,highlightthickness=0,
                    text="About System",
                    fg="blue",
                    font=("Areal",10,"underline"),
                    bg="lightgray",
                    command=AboutSystem,
                    height=3,
                    activebackground="lightgray",
                    activeforeground="blue",
                    compound="right"
                    )
    About_System.pack(anchor="e",padx=50)
    About_System.pack_propagate(False)

    Text_Container_One = Label(About_Us_Text_Conatiner)
    Text_Container_One.pack(anchor="w",padx=10)

    Text_Container_Two = Label(About_Us_Text_Conatiner)
    Text_Container_Two.pack(anchor="w",padx=10)

# User Manual Funtion
def UserManual():
    global User_Manual
    User_Manual = Toplevel(window,bg="#E5E5E5")
    User_Manual.title("User Manual")
    User_Manual.geometry("700x450")
    User_Manual.resizable(False,False)

    Manual.config(state="disabled")
    User_Manual.protocol("WM_DELETE_WINDOW",NormalUserManual)

    Label(User_Manual,text="User Manual",font=("Times new roman",15,"bold"),bg="#E5E5E5").pack(pady=20)
    Label(User_Manual,text= "Welcome to the LuckymePayless Gasoline System!\n\n"
            "This system helps manage gasoline transactions efficiently.\n\n"
            "How to Use:\n"
            "1. Click on 'Gasoline Price' to view current fuel prices.\n"
            "2. Select the gasoline type (Diesel, Premium, Unleaded, or Kerosene).\n"
            "3. Enter the desired amount and payment.\n"
            "4. Click 'Complete Transaction' to generate a receipt.\n\n"
            "Features:\n"
            "• Real-time receipt generation.\n"
            "• Automatic change computation.\n"
            "• Easy-to-navigate interface.\n"
            "• Accurate and user-friendly.\n\n"
            "Tips:\n"
            "• Make sure to input correct payment to avoid errors.\n"
            "• Check the receipt for transaction details.\n"
            "• Use the 'About Us' section to learn more about the developers.",
            justify="left",
            font=("Arial",10),
            bg="#E5E5E5").pack(anchor="w",padx=20)

# Gasoline Price Funtion
def GasolinePrice():
    global Price_Container
    Price_Container = Toplevel(window,bg="black")   
    Price_Container.title("Price Of Gasoline")
    Price_Container.geometry("335x600")
    Price_Container.resizable(False,False)
    Price_Container.config(bg="#FAEAC8")

    Gasoline_Price.config(state="disabled")
    Price_Container.protocol("WM_DELETE_WINDOW",NormalGasolinePrice)

    LLogo = Label(Price_Container,image=Photo,bg="#FAEAC8")
    LLogo.pack()


    Diesel_Price_Container = Text(Price_Container,height=1,width=80,borderwidth=0,font=("Times new roman",20,"bold"),bg="lightgray")
    Diesel_Price_Container.pack(pady=10,padx=10)
    Diesel_Price_Container.insert(0.1,"  Diesel       \t\t","Diesel_Unit\t")
    Diesel_Price_Container.insert("end","    40\t","Diesel_Price")
    Diesel_Price_Container.tag_config("Diesel_Unit",background="Lightgray",)
    Diesel_Price_Container.tag_config("Diesel_Price",background="Black",foreground="White")
    Diesel_Price_Container.config(state="disabled")

    Premium_Price_Container = Text(Price_Container,height=1,width=80,borderwidth=0,font=("Times new roman",20,"bold"),bg="lightgray")
    Premium_Price_Container.pack(pady=10,padx=10)
    Premium_Price_Container.insert(0.1,"  Premium       \t\t","Diesel_Unit\t")
    Premium_Price_Container.insert("end","    40\t","Diesel_Price")
    Premium_Price_Container.tag_config("Diesel_Unit",background="Lightgray",)
    Premium_Price_Container.tag_config("Diesel_Price",background="Black",foreground="White")
    Premium_Price_Container.config(state="disabled")

    Unleaded_Price_Container = Text(Price_Container,height=1,width=80,borderwidth=0,font=("Times new roman",20,"bold"),bg="lightgray")
    Unleaded_Price_Container.pack(pady=10,padx=10)
    Unleaded_Price_Container.insert(0.1,"  Unleaded       \t\t","Diesel_Unit\t")
    Unleaded_Price_Container.insert("end","    41\t","Diesel_Price")
    Unleaded_Price_Container.tag_config("Diesel_Unit",background="Lightgray",)
    Unleaded_Price_Container.tag_config("Diesel_Price",background="Black",foreground="White")
    Unleaded_Price_Container.config(state="disabled")

    Kerosene_Price_Container = Text(Price_Container,height=1,width=80,borderwidth=0,font=("Times new roman",20,"bold"),bg="lightgray")
    Kerosene_Price_Container.pack(pady=5,padx=10)
    Kerosene_Price_Container.insert(0.1,"  Kerosene     \t\t","Diesel_Unit\t")
    Kerosene_Price_Container.insert("end","    35\t","Diesel_Price")
    Kerosene_Price_Container.tag_config("Diesel_Unit",background="Lightgray")
    Kerosene_Price_Container.tag_config("Diesel_Price",background="Black",foreground="White")
    Kerosene_Price_Container.config(state="disabled")

# Diesel Funtion
def Diesel():
    # This is transaction funtion
    def Transaction():
        # trying this code
        try:
            global Change
            Change = int(Diesel_Payment.get()) - int(Diesel_Amount.get())

            global Total_Amount
            
            Total_Amount = int(Diesel_Amount.get())
            if int(Diesel_Payment.get()) >= int(Diesel_Amount.get()):
                Receipt()
            else:
                # If your money is not enough
                messagebox.showerror("Invalid","Your payment is not enough")

            Diesel_Amount.delete(0,END)
            Diesel_Payment.delete(0,END)

        except ValueError:# If you enter invalid value / not a number
            messagebox.showerror("Error","Please enter numerical value")

    global Gasoline_Type_Diesel
    Gasoline_Type_Diesel = Toplevel(window,bg="lightgray")
    Gasoline_Type_Diesel.geometry("600x400")
    Gasoline_Type_Diesel.resizable(False,False)
    Gasoline_Type_Diesel.title("Diesel")

    Diesel.config(state="disabled")
    Gasoline_Type_Diesel.protocol("WM_DELETE_WINDOW",NormalDiesel)
    
    Label(Gasoline_Type_Diesel, text="Enter Amount: ",font= ("Times new roman", 10 ,"bold"),bg="lightgray").pack()
    Diesel_Amount = Entry(Gasoline_Type_Diesel)
    Diesel_Amount.pack()

    Label(Gasoline_Type_Diesel, text="Enter Payment: ",font= ("Times new roman", 10 ,"bold"),bg="lightgray").pack()
    Diesel_Payment = Entry(Gasoline_Type_Diesel)
    Diesel_Payment.pack()
    
    #Transaction Button
    Transaction_Button = Button(Gasoline_Type_Diesel,text="Complete Transaction", command=Transaction,bg="darkgreen")
    Transaction_Button.pack(pady=10)

    Exit_Button = Button(Gasoline_Type_Diesel,text="Exit", command=Gasoline_Type_Diesel.destroy,width=10,bg="red",fg="white")
    Exit_Button.place(x=10,y=350)

# Premium Funtion
def Premium():
    def Transaction():
        try:
            global Change
            Change = int(Premium_Payment.get()) - int(Premium_Amount.get())
            
            global Total_Amount

            Total_Amount = int(Premium_Amount.get())
            if int(Premium_Payment.get()) >= int(Premium_Amount.get()):
                Receipt()
            else:
                messagebox.showerror("Invalid","Your payment is not enough")

            Premium_Amount.delete(0,END)
            Premium_Payment.delete(0,END)

        except ValueError:
            messagebox.showerror("Error","Please enter numerical value")

    global Gasoline_Type_Premium
    Gasoline_Type_Premium = Toplevel(window,bg="lightgray")
    Gasoline_Type_Premium.geometry("600x400")
    Gasoline_Type_Premium.resizable(False,False)
    Gasoline_Type_Premium.title("Premium")

    Premium.config(state="disabled")
    Gasoline_Type_Premium.protocol("WM_DELETE_WINDOW",NormalPremium)

    Label(Gasoline_Type_Premium, text="Enter Amount: ",font= ("Times new roman", 10 ,"bold"),bg="lightgray").pack()
    Premium_Amount = Entry(Gasoline_Type_Premium)
    Premium_Amount.pack()

    Label(Gasoline_Type_Premium, text="Enter Payment: ",font= ("Times new roman", 10 ,"bold"),bg="lightgray").pack()
    Premium_Payment = Entry(Gasoline_Type_Premium)
    Premium_Payment.pack()
    
    #Transaction Button
    Transaction_Button = Button(Gasoline_Type_Premium,text="Complete Transaction", command=Transaction,bg="darkgreen")
    Transaction_Button.pack(pady=10)

    Exit_Button = Button(Gasoline_Type_Premium,text="Exit", command=Gasoline_Type_Premium.destroy,width=10,bg="red",fg="white")
    Exit_Button.place(x=10,y=350)

# Unleaded Funtion
def Unleaded():
    def Transaction():
        try:
            global Change
            global Total_Amount
            Change = int(Unleaded_Payment.get()) - int(Unleaded_Amount.get())
            Total_Amount = int(Unleaded_Amount.get())

            if int(Unleaded_Payment.get()) >= int(Unleaded_Amount.get()):
                Receipt()
            else:
                messagebox.showerror("Invalid","Your payment is not enough")

            Unleaded_Amount.delete(0,END)
            Unleaded_Payment.delete(0,END)

        except ValueError:
            messagebox.showerror("Error","Please enter numerical value")

    global Gasoline_Type_Unleaded
    Gasoline_Type_Unleaded = Toplevel(window,bg="lightgray")
    Gasoline_Type_Unleaded.geometry("600x400")
    Gasoline_Type_Unleaded.resizable(False,False)
    Gasoline_Type_Unleaded.title("Unleaded")
    
    Unleaded.config(state="disabled")
    Gasoline_Type_Unleaded.protocol("WM_DELETE_WINDOW",NormalUnleaded)

    Label(Gasoline_Type_Unleaded , text="Enter Amount: ",font= ("Times new roman", 10 ,"bold"),bg="lightgray").pack()
    Unleaded_Amount = Entry(Gasoline_Type_Unleaded )
    Unleaded_Amount.pack()

    Label(Gasoline_Type_Unleaded , text="Enter Payment: ",font= ("Times new roman", 10 ,"bold"),bg="lightgray").pack()
    Unleaded_Payment = Entry(Gasoline_Type_Unleaded )
    Unleaded_Payment.pack()
    
    #Transaction Button
    Transaction_Button = Button(Gasoline_Type_Unleaded ,text="Complete Transaction", command=Transaction,bg="darkgreen")
    Transaction_Button.pack(pady=10)

    Exit_Button = Button(Gasoline_Type_Unleaded ,text="Exit", command=Gasoline_Type_Unleaded .destroy,width=10,bg="red",fg="white")
    Exit_Button.place(x=10,y=350)

def Kerosene():
    def Transaction():
        try:
            global Change
            Change = int(Kerosene_Payment.get()) - int(Kerosene_Amount.get())

            global Total_Amount
            
            Total_Amount = int(Kerosene_Amount.get())
            if int(Kerosene_Payment.get()) >= int(Kerosene_Amount.get()):
                Receipt()
            else:
                messagebox.showerror("Invalid","Your payment is not enough")
 
            Kerosene_Amount.delete(0,END)
            Kerosene_Payment.delete(0,END)

        except ValueError:
            messagebox.showerror("Error","Please enter numerical value")
            
    # This is the kerosene window 
    global Gasoline_Type_Kerosene
    Gasoline_Type_Kerosene = Toplevel(window,bg="lightgray")
    Gasoline_Type_Kerosene.geometry("600x400")
    Gasoline_Type_Kerosene.resizable(False,False)
    Gasoline_Type_Kerosene.title("Premium")

    Kerosene.config(state="disabled")
    Gasoline_Type_Kerosene.protocol("WM_DELETE_WINDOW",NormalKerosene)
    
    Label(Gasoline_Type_Kerosene, text="Enter Amount: ",font= ("Times new roman", 10 ,"bold"),bg="lightgray").pack()
    Kerosene_Amount = Entry(Gasoline_Type_Kerosene)
    Kerosene_Amount.pack()

    Label(Gasoline_Type_Kerosene, text="Enter Payment: ",font= ("Times new roman", 10 ,"bold"),bg="lightgray").pack()
    Kerosene_Payment = Entry(Gasoline_Type_Kerosene)
    Kerosene_Payment.pack()
    
    #Transaction Button
    Transaction_Button = Button(Gasoline_Type_Kerosene,text="Complete Transaction", command=Transaction,bg="darkgreen")
    Transaction_Button.pack(pady=10)

    Exit_Button = Button(Gasoline_Type_Kerosene,text="Exit", command=Gasoline_Type_Kerosene.destroy,width=10,bg="red",fg="white")
    Exit_Button.place(x=10,y=350)

# Window Destroy
def WindowClose():
    window.destroy()

# Good Bye Sound
def GoodBye():
    # Setting the sound
    Goood_Bye_Sound = mixer.Sound("Good_Bye_Sound.mp3")
    Goood_Bye_Sound.play()

    # After 1.88 second you call WindowClose funtion
    window.after(1880,WindowClose)

window =  Tk()
window.state("zoomed")
window.resizable(False,False)
window.title("Gasoline System")
window.config(bg="lightgray")
window.protocol("WM_DELETE_WINDOW",GoodBye)

Welcome_Sound = mixer.Sound("Welcome_Sound.mp3")

# Welcome_Sound.set_volume(1)
Welcome_Sound.play()

# global Photo
Photo = PhotoImage(file="System_Logo.png")
Photo = Photo.subsample(2,2)
Photo_Re = PhotoImage(file="System_Logo_Re.png")
Main_Window_Logo_Photo = Photo_Re.subsample(2,2)
Main_Window_Logo_Photo = Main_Window_Logo_Photo.zoom(1,1)
window.iconphoto(True,Photo)

# this is the frame/container of all button on the top part (price, about-us, user-manuak )
Nav_container =  Frame(window ,bg="#2E7D32", height=20 , width=1300, bd=0 ,highlightthickness=0)
Nav_container.pack(fill="x")

# this is About Us Button
About_Us_button =  Button(Nav_container,text="About Us",bg="#66BB6A",fg="#2C2C2C",activebackground="#66BB6A")
About_Us_button.pack(side="right" , padx=10 , pady=10)
About_Us_button.config(command=AboutUs)

# this is Gasoline price button
Gasoline_Price = Button(Nav_container, text="Gasoline Price",command=GasolinePrice,bg="#66BB6A",fg="#2C2C2C",activebackground="#66BB6A")
Gasoline_Price.pack(side="left",padx=10)

# this is the User Manual Button
Manual =  Button(Nav_container,text="User Manual",bg="#66BB6A",fg="#2C2C2C",activebackground="#66BB6A")
Manual.config(command=UserManual)
Manual.pack(side="right",padx=10,pady=10)

# this is the frame/container of all fuel button 
Gasoline_Type_Container = Frame(window,bg="lightgray")
Gasoline_Type_Container.pack(anchor='w',pady=10,padx=10)

# setting up all fuel button
Diesel = Button(Gasoline_Type_Container,text="Diesel",width=10,command=Diesel,bg="#66BB6A",fg="#2C2C2C" ,activebackground="#66BB6A")
Diesel.pack(pady=10)

Premium = Button(Gasoline_Type_Container, text="Premium",width=10,command=Premium,bg="#66BB6A",fg="#2C2C2C",activebackground="#66BB6A")
Premium.pack(pady=10)

Unleaded = Button(Gasoline_Type_Container,text="Unleaded",width=10,command=Unleaded,bg="#66BB6A",fg="#2C2C2C",activebackground="#66BB6A")
Unleaded.pack(pady=10)

Kerosene = Button(Gasoline_Type_Container,text="Kerosene",width=10,command=Kerosene,bg="#66BB6A",fg="#2C2C2C",activebackground="#66BB6A")
Kerosene.pack(pady=10)


Main_Window_Logo_Conatiner = Frame(window,bg="lightgray")
Main_Window_Logo_Conatiner.place(x=400 , y=100)
Main_Window_Logo = Label(Main_Window_Logo_Conatiner,image=Main_Window_Logo_Photo,bg="lightgray")
Main_Window_Logo.pack()


window.mainloop()