from tkinter import *

Window = Tk()
Window.geometry("700x450")
Label(Window,text="User Manual",font=("Times new roman",15,"bold")).pack(pady=20)
Label(Window,text= "Welcome to the LuckymePayless Gasoline System!\n\n"
        "This system helps manage gasoline transactions efficiently.\n\n"
        "How to Use:\n"
        "1. Click on 'Gasoline Price' to view current fuel prices.\n"
        "2. Select the gasoline type (Diesel, Premium, Unleaded, or Kerosene).\n"
        "3. Enter the desired amount and payment.\n"
        "4. Click 'Complete Transaction' to generate a receipt.\n\n"
        "Features:\n"
        "• Real-time receipt generation.\n"
        "• Automatic change computation.\n"
        "• Easy-to-navigate interface.\n"
        "• Accurate and user-friendly.\n\n"
        "Tips:\n"
        "• Make sure to input correct payment to avoid errors.\n"
        "• Check the receipt for transaction details.\n"
        "• Use the 'About Us' section to learn more about the developers.",
        justify="left",
        font=("Arial",10)).pack(anchor="w",padx=20)

Window.mainloop()