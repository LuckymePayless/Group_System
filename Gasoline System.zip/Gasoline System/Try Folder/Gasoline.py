from tkinter import *

#About us
def AboutUs():
    About_Us =  Toplevel(window)
    About_Us.geometry("300x250")

    Name =  Label(About_Us, text="Programes name\n\n"
                  "● Ilyer Jhon Sibayan Tapiz\n"
                  "● Josie Tindaan Tapiz"
                  )
    
    Name.config(justify="left",fg="green")
    Name.pack(anchor="e",padx=80 ,pady=10)

def UserManual():
    User_Manual = Toplevel(window)
    User_Manual.geometry("600x400")
    
    Manual_Scipt = Label(User_Manual,text="kahit ano na")
    Manual_Scipt.pack()


window =  Tk()
# window.title ="Gasolin System"

#Navigation holder
Nav_container =  Frame(window ,bg="lightgray", height=20 , width=1300, bd=0 ,highlightthickness=0)
Nav_container.pack(fill="x")

#About us button
About_Us_button =  Button(Nav_container,text="About Us", fg="green")
About_Us_button.pack(side="right" , padx=10 , pady=10)
About_Us_button.config(command=AboutUs)

#User Manual
Manual =  Button(Nav_container,text="User Manual",fg="green")
Manual.config(command=UserManual)
Manual.pack(side="right",padx=10,pady=10)

#Gasoline Type Container
Gasoline_Type_Container = Frame(window, bg="green")
Gasoline_Type_Container.pack()

#Diesel
Diesel = Button(Gasoline_Type_Container,text="Diesel")
Diesel.pack()



window.geometry("1300x700")
window.mainloop()