from tkinter import *

Window = Tk()
Window.title("Gasoline Price")
Window.geometry("335x600")
Window.config(bg="#FAEAC8")

Logo = PhotoImage(file="System_Logo.png")
xLogo = Logo.subsample(3,3)

LLogo = Label(Window,image=xLogo,bg="#FAEAC8")
LLogo.pack()


Diesel_Price_Container = Text(Window,height=1,width=80,borderwidth=0,font=("Times new roman",20,"bold"),bg="lightgray")
Diesel_Price_Container.pack(pady=10,padx=10)
Diesel_Price_Container.insert(0.1,"  Diesel       \t\t","Diesel_Unit\t")
Diesel_Price_Container.insert("end","    40\t","Diesel_Price")
Diesel_Price_Container.tag_config("Diesel_Unit",background="Lightgray",)
Diesel_Price_Container.tag_config("Diesel_Price",background="Black",foreground="White")
Diesel_Price_Container.config(state="disabled")

Premium_Price_Container = Text(Window,height=1,width=80,borderwidth=0,font=("Times new roman",20,"bold"),bg="lightgray")
Premium_Price_Container.pack(pady=10,padx=10)
Premium_Price_Container.insert(0.1,"  Premium       \t\t","Diesel_Unit\t")
Premium_Price_Container.insert("end","    40\t","Diesel_Price")
Premium_Price_Container.tag_config("Diesel_Unit",background="Lightgray",)
Premium_Price_Container.tag_config("Diesel_Price",background="Black",foreground="White")
Premium_Price_Container.config(state="disabled")

Unleaded_Price_Container = Text(Window,height=1,width=80,borderwidth=0,font=("Times new roman",20,"bold"),bg="lightgray")
Unleaded_Price_Container.pack(pady=10,padx=10)
Unleaded_Price_Container.insert(0.1,"  Unleaded       \t\t","Diesel_Unit\t")
Unleaded_Price_Container.insert("end","    41\t","Diesel_Price")
Unleaded_Price_Container.tag_config("Diesel_Unit",background="Lightgray",)
Unleaded_Price_Container.tag_config("Diesel_Price",background="Black",foreground="White")
Unleaded_Price_Container.config(state="disabled")

Kerosene_Price_Container = Text(Window,height=1,width=80,borderwidth=0,font=("Times new roman",20,"bold"),bg="lightgray")
Kerosene_Price_Container.pack(pady=5,padx=10)
Kerosene_Price_Container.insert(0.1,"  Kerosene     \t\t","Diesel_Unit\t")
Kerosene_Price_Container.insert("end","    35\t","Diesel_Price")
Kerosene_Price_Container.tag_config("Diesel_Unit",background="Lightgray")
Kerosene_Price_Container.tag_config("Diesel_Price",background="Black",foreground="White")
Kerosene_Price_Container.config(state="disabled")




Window.mainloop()
