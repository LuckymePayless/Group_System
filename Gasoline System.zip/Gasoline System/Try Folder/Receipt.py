from tkinter import *
import datetime

Date = datetime.datetime.now()
# CurrentDate = Date.date()
CurrentDate =Date.strftime("%B %d %Y")
CurrentTime = Date.strftime("%I:%M %p")


#If else \\elif
num = input("nuber: ")

Window = Tk()
Window.geometry("300x600")
Window.config(bg="#FAEAC8")

Label(Window,text="LuckymePayless",bg="#FAEAC8",font=("Times new roman",15,"bold")).pack(side=TOP,pady=10)
Label(Window,text="Heinics@gamil.com\n"
      "093-343-324-243"
      ,bg="#FAEAC8").pack()
Label(Window,text="---------------------------------------------------------------------",bg="#FAEAC8").pack()
Label(Window,text=f'  {CurrentDate}\t\t\t{CurrentTime}',bg="#FAEAC8").pack(anchor="w")
Label(Window,text="---------------------------------------------------------------------",bg="#FAEAC8").pack()
Label(Window,text="---------------------------------------------------------------------",bg="#FAEAC8").pack()
Label(Window,text=f'  Total\t\t\t\t     {num}',bg="#FAEAC8").pack(anchor="w")
Label(Window,text="---------------------------------------------------------------------",bg="#FAEAC8").pack()
Label(Window,text="Thank You",font=("Arial",15,"bold"),bg="#FAEAC8").pack(side="bottom",pady=20)

Window.mainloop()