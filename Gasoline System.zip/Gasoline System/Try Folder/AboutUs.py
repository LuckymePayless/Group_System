# "Welcome to Gasoline System, a platform designed to provide an efficient"
# "and reliable way of managing gasoline-related transactions and records. "
# "Our goal is to simplify operations by offering a user-friendly system "
# "that ensures accuracy, convenience, and smooth workflow."
# "This system was proudly developed by our dedicated team of programmers:"

# Ilyer
# Josie
# Grace
# Kanojo

# "With teamwork, dedication, and innovation, we built Gasoline System\n"
# "to meet the needs of businesses and individuals who rely on accurate \n"
# "monitoring and management. We are committed to continuous improvement,\n"
# "ensuring that the system grows with the evolving demands of its users\n"
# "\nAt Gasoline System, we value:
# "Efficiency – making transactions faster and more reliable.\n"
# "Accuracy – ensuring data and records are correct.\n"
# "Innovation – developing features that enhance user experience.\n"
# "Thank you for choosing Gasoline System. Together, we fuel progress\n"

from tkinter import *



def Autor():

      # global Author_welcome_Text
      # Author_welcome_Text = Label(About_Us_Text_Conatiner, 
      #       text="Welcome to Gasoline System, a platform \n"
      #       "designed to provide an efficient and reliable\n"
      #       "way of managing gasoline-related transactions \n"
      #       "and records.\n"
      #       "Our goal is to simplify operations by offering\n"
      #       "a user-friendly system that ensures accuracy,\n"
      #       "convenience, and smooth workflow.\n"
      #       "This system was proudly developed by our dedicated\n"
      #       "team of programmers:\n"
      #       "-----------------",
      #       font=("Times new roman",10,"bold"),
      #       fg="green",
      #       justify="left"
      #       )
      # Author_welcome_Text.pack(anchor="w",padx=10,pady=10)
      # Label(About_Us_Text_Conatiner,
      #       font=("Areal",10),
      #       text="● Ilyer Jhon Sibayan Tapiz\n"
      #       "● Josie Caw-as Tindaan",
      #       justify="left"
      #       ).pack(anchor="w",padx=10)

      Text_Container_One.config(text="Welcome to Gasoline System, a platform \n"
            "designed to provide an efficient and reliable\n"
            "way of managing gasoline-related transactions \n"
            "and records.\n"
            "Our goal is to simplify operations by offering\n"
            "a user-friendly system that ensures accuracy,\n"
            "convenience, and smooth workflow.\n"
            "This system was proudly developed by our dedicated\n"
            "team of programmers:\n"
            "------------------------------------",
            font=("Times new roman",10,"bold"),
            fg="green",
            justify="left"
            )
      Text_Container_Two.config(font=("Areal",10),
            text="● Ilyer Jhon Sibayan Tapiz\n"
            "● Josie Caw-as Tindaan",
            justify="left"
            )
      
def AboutSystem():
      Text_Container_One.config( 
            text="With teamwork, dedication, and innovation,\n"
            "we built Gasoline System to meet the needs of \n"
            "businesses and individuals who rely on accurate \n"
            "monitoring and management. We are committed to \n"
            "continuous improvement, ensuring that the system \n"
            "grows with the evolving demands of its users\n"
            "\nAt Gasoline System, we value:"
            "Efficiency – making transactions faster and more reliable.\n"
            "Accuracy – ensuring data and records are correct.\n"
            "Innovation – developing features that enhance user experience.\n"
            "Thank you for choosing Gasoline System. Together, we fuel progress\n"
,
            font=("Times new roman",10,"bold"),
            fg="green",
            justify="left"
            )
      Text_Container_Two.config(text="")
      # Author_welcome_Text.config(text="")

window = Tk()
window.title("About Us")

Icon = PhotoImage(file="Logo.png")
window.iconphoto(False , Icon)

Logo = PhotoImage(file="System_Logo.png")

System_Logo = Label(window,image=Logo)
System_Logo.pack()
System_Logo.place(x=190,y=90)

# System_Logo = Label(window,image=Logo)
# System_Logo.pack(anchor="w",padx=80,pady=80)

Heading = Label(window,text="Gasoline System",font=("Times new roman",40,"bold","underline"))
Heading.pack()
Heading.place(x=890, y=100)


About_Us_Text_Conatiner = Frame(window,height=300,width=400,bd=2,relief="solid")
About_Us_Text_Conatiner.place(x=880,y=300)
About_Us_Text_Conatiner.pack_propagate(FALSE)
About_Us_Nav_Conatiner = Frame(window,bg="lightgray",height=0)
About_Us_Nav_Conatiner.pack(side="bottom",fill="x")

Autors = Button(About_Us_Nav_Conatiner,
                bd=0,highlightthickness=0,
                text="Authors",
                fg="blue",
                font=("Areal",10,"underline"),
                bg="lightgray",
                command=Autor,
                height=3,
                activebackground="lightgray",
                activeforeground="blue"
                )
Autors.pack()
Autors.place(y=0,x=200)
Autors.pack_propagate(False)


About_System = Button(About_Us_Nav_Conatiner,
                bd=0,highlightthickness=0,
                text="About System",
                fg="blue",
                font=("Areal",10,"underline"),
                bg="lightgray",
                command=AboutSystem,
                height=3,
                activebackground="lightgray",
                activeforeground="blue",
                compound="right"
                )
About_System.pack(anchor="e",padx=200)
About_System.pack_propagate(False)

Text_Container_One = Label(About_Us_Text_Conatiner)
Text_Container_One.pack(anchor="w",padx=10)

Text_Container_Two = Label(About_Us_Text_Conatiner)
Text_Container_Two.pack(anchor="w",padx=10)

window.geometry("1300x700")
window.mainloop()